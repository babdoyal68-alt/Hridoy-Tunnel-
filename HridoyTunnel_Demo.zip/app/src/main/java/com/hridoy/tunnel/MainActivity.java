package com.hridoy.tunnel;
import android.graphics.Color; import android.os.Bundle; import android.view.Gravity; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 boolean connected=false; TextView status; Button connect;
 TextView t(String s,float z,int c){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(c);x.setGravity(Gravity.CENTER);x.setPadding(8,8,8,8);return x;}
 public void onCreate(Bundle b){super.onCreate(b);
  LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER_HORIZONTAL);r.setPadding(24,24,24,24);r.setBackgroundColor(Color.rgb(7,17,27));
  ImageView im=new ImageView(this);im.setImageResource(R.drawable.logo);im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);r.addView(im,new LinearLayout.LayoutParams(-1,230));
  TextView title=t("Hridoy Tunnel",28,Color.WHITE);title.setTypeface(null,1);r.addView(title);
  r.addView(t("Hridoy Tunnel - Fast & Secure",15,Color.rgb(170,184,197)));
  TextView demo=t("DEMO MODE • VPN SERVER NOT CONNECTED",12,Color.rgb(255,210,80));demo.setPadding(8,18,8,18);r.addView(demo);
  LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setBackgroundResource(R.drawable.bg_card);
  LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,10,0,18);r.addView(card,cp);
  TextView loc=t("🇸🇦  Saudi Arabia",20,Color.WHITE);loc.setTypeface(null,1);card.addView(loc);
  status=t("Disconnected",16,Color.rgb(255,100,100));card.addView(status);
  connect=new Button(this);connect.setText("CONNECT");connect.setTextSize(18);connect.setTextColor(Color.rgb(5,25,15));connect.setAllCaps(false);connect.setBackgroundResource(R.drawable.bg_button);r.addView(connect,new LinearLayout.LayoutParams(240,62));
  r.addView(t("This demo changes the interface only.\nIt does not provide free internet or bypass mobile-operator limits.",12,Color.rgb(150,165,175)));
  connect.setOnClickListener(v->{connected=!connected;if(connected){status.setText("Connected • Demo");status.setTextColor(Color.rgb(32,243,107));connect.setText("STOP");connect.setTextColor(Color.WHITE);connect.setBackgroundResource(R.drawable.bg_button_off);Toast.makeText(this,"Demo connection enabled",Toast.LENGTH_SHORT).show();}else{status.setText("Disconnected");status.setTextColor(Color.rgb(255,100,100));connect.setText("CONNECT");connect.setTextColor(Color.rgb(5,25,15));connect.setBackgroundResource(R.drawable.bg_button);}});
  setContentView(r);
 }
}