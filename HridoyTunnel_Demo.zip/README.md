# Hridoy Tunnel — Demo
Your supplied logo is included. Branding: **Hridoy Tunnel - Fast & Secure**. Server shown: **Saudi Arabia**.
This is a UI demo only; it does not create a real VPN tunnel or bypass carrier limits.
Open in Android Studio, sync Gradle, then Build > Build APK(s).
